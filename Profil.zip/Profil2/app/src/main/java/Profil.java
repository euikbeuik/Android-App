public class Profil {

    private String Username;
    private String Passwort;
    private String Fraktion;

    public Profil (String username , String passwort , String fraktion) {
        this.Username = username;
        this.Passwort = passwort;
        this.Fraktion = fraktion;
    }
    public String getUsername() {
        return Username;
    }

    public String getPasswort() {
        return Passwort;
    }

    public String getFraktion() {
        return Fraktion;
    }


}
